package com.mobile.tests;

import com.mobile.pages.LoginPage;
import com.mobile.pages.Utills.LoggerHelper;
import org.testng.annotations.Test;

public class LoginTest {

    @Test
    public void testLogin() {
        LoginPage loginPage = new LoginPage();
        loginPage.enterUsername("testuser");
        loginPage.enterPassword("password123");
        loginPage.clickLogin();

        LoggerHelper log = new LoggerHelper(LoginTest.class);



            log.info("Test started");
            log.debug("Performing some operation...");
            log.error("Oops! Something went wrong.");
            log.info("Test ended");
        }
    }