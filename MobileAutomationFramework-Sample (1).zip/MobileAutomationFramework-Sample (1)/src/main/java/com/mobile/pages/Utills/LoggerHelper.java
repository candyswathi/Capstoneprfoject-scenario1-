package com.mobile.pages.Utills;

public class LoggerHelper {

    private final String className;//this is to provide the classname

    public LoggerHelper(Class<?> clazz) {
        this.className = clazz.getSimpleName();
    }

    public void info(String message) {
        System.out.println("[INFO] [" + className + "] " + message);
    }

    public void error(String message) {
        System.out.println("[ERROR] [" + className + "] " + message);
    }

    public void debug(String message) {
        System.out.println("[DEBUG] [" + className + "] " + message);
    }
}
