package com.mobile.pages.Utills;

public class ExtentManager {

    public static void initReport() {
        System.out.println("Extent Report initialized.");
    }

    public static void logPass(String message) {
        System.out.println("PASS: " + message);
    }

    public static void logFail(String message) {
        System.out.println("FAIL: " + message);
    }

    public static void flushReport() {
        System.out.println("Extent Report flushed.");
    }
}
