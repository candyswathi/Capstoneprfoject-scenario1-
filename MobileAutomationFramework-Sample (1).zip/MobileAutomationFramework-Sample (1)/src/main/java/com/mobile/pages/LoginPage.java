package com.mobile.pages;


import com.mobile.pages.Utills.LoggerHelper;

public class LoginPage {

    LoggerHelper log = new LoggerHelper(LoginPage.class);

    public void enterUsername(String username) {
        log.info("Entering username: " + username);
    }

    public void enterPassword(String password) {
        log.info("Entering password: " + password);
    }

    public void clickLogin() {
        log.info("Clicked Login button.");
    }
}